﻿namespace xNet
{
    /// <summary>
    /// Тип прокси-сервера.
    /// </summary>
    public enum ProxyType
    {
        Http,
        Socks4,
        Socks4a,
        Socks5,
        Chain
    }
}