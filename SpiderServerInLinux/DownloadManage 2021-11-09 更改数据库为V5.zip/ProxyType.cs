namespace Yove.Proxy
{
    public enum ProxyType
    {
        Http,
        Socks4,
        Socks5
    }
}