﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpiderServerInLinux
{
    internal class Code
    {
        private static void main()
        {
            Console.WriteLine("Hello");
        }
    }
}