﻿using Microsoft.VisualBasic.FileIO;

using Shadowsocks.Util;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Shadowsocks.Controller
{
    public static class I18N
    {
        public const string I18N_FILE = "i18n.csv";

        private static Dictionary<string, string> _strings = new Dictionary<string, string>();

        private static void Init(string res, string locale)
        {
            using (TextFieldParser csvParser = new TextFieldParser(new StringReader(res)))
            {
                csvParser.SetDelimiters(",");

                // search language index
                string[] localeNames = csvParser.ReadFields();

                int enIndex = 0;
                int targetIndex = -1;

                for (int i = 0; i < localeNames.Length; i++)
                {
                    if (localeNames[i] == "en")
                        enIndex = i;
                    if (localeNames[i] == locale)
                        targetIndex = i;
                }

                // Fallback to same language with different region
                if (targetIndex == -1)
                {
                    string localeNoRegion = locale.Split('-')[0];
                    for (int i = 0; i < localeNames.Length; i++)
                    {
                        if (localeNames[i].Split('-')[0] == localeNoRegion)
                            targetIndex = i;
                    }
                    if (targetIndex != -1 && enIndex != targetIndex)
                    {
                    }
                    else
                    {
                        // Still not found, exit
                        return;
                    }
                }

                // read translation lines
                while (!csvParser.EndOfData)
                {
                    string[] translations = csvParser.ReadFields();
                    string source = translations[enIndex];
                    string translation = translations[targetIndex];

                    // source string or translation empty
                    if (string.IsNullOrWhiteSpace(source) || string.IsNullOrWhiteSpace(translation)) continue;
                    // line start with comment
                    if (translations[0].TrimStart(' ')[0] == '#') continue;

                    _strings[source] = translation;
                }
            }
        }

        static I18N()
        {
            string i18n = "";
            string locale = CultureInfo.CurrentCulture.Name;
            if (!File.Exists(I18N_FILE))
            {
                //File.WriteAllText(I18N_FILE, i18n, Encoding.UTF8);
            }
            else
            {
                //i18n = File.ReadAllText(I18N_FILE, Encoding.UTF8);
            }
            //Init(i18n, locale);
        }

        public static string GetString(string key, params object[] args)
        {
            return string.Format(_strings.TryGetValue(key.Trim(), out var value) ? value : key, args);
        }
    }
}