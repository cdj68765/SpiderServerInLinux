﻿using Cowboy.WebSockets;
using LiteDB;
using System;
using System.Buffers;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace SpiderServerInLinux
{
    internal class Image2Webp : AsyncWebSocketServerModule
    {
        private ConcurrentStack<SendData> DisConnectMission = new ConcurrentStack<SendData>();
        private static BlockingCollection<SendData> WriteSend = new BlockingCollection<SendData>(10);
        private static BlockingCollection<ImgData> WriteSave = new BlockingCollection<ImgData>();

        public ConcurrentDictionary<string, List<SendData>> _sessionsMission = new ConcurrentDictionary<string, List<SendData>>();

        public ConcurrentDictionary<string, bool> _sessionsCheck = new ConcurrentDictionary<string, bool>();
        private SendMessage sendMessage = new SendMessage();
        private static ConcurrentQueue<string> MessageList = new ConcurrentQueue<string>();

        [Serializable]
        public class SendMessage
        {
            public int ReadFromSIS;
            public int ReadFromT66y;
            public int SendCount;
            public int SaveCount;

            public Dictionary<string, CLientInfo> ClientCount = new Dictionary<string, CLientInfo>();

            public List<string> Message = new List<string>();
            public int WaitSendCount;
            public int WaitSaveCount;
            public string Mem;

            public byte[] Send()
            {
                Message.Clear();

                foreach (var item in MessageList.ToArray())
                    Message.Add(item);
                WaitSendCount = WriteSend.Count;
                WaitSaveCount = WriteSave.Count;
                Mem = $"内存使用量:{Process.GetCurrentProcess().WorkingSet64 / 1024 / 1024}MB";
                using (MemoryStream stream = new MemoryStream())
                {
                    BinaryFormatter Formatter = new BinaryFormatter();
                    Formatter.Serialize(stream, this);
                    return stream.ToArray();
                }
            }

            public static SendMessage ToClass(byte[] data)
            {
                using var stream = new MemoryStream(data);
                IFormatter Fileformatter = new BinaryFormatter();
                Fileformatter.Binder = new UBinder();
                return Fileformatter.Deserialize(stream) as SendMessage;
            }

            public class UBinder : SerializationBinder
            {
                public override Type BindToType(string assemblyName, string typeName)
                {
                    if (typeName.EndsWith("SendMessage"))
                    {
                        return typeof(SendMessage);
                    }
                    return (Assembly.GetExecutingAssembly()).GetType(typeName);
                }
            }
        }

        [Serializable]
        public class CLientInfo
        {
            public int SendCount;
            public int GetCount;
            public long SendByte;
            public long GetByte;
        }

        [Serializable]
        public class OriImgData : SISImgData
        {
            public new bool Status;
        }

        [Serializable]
        internal class ImgData2 : T66yImgData
        {
            public string Type { get; set; }

            public static ImgData ToClass(byte[] data)
            {
                using var stream = new MemoryStream(data);
                IFormatter Fileformatter = new BinaryFormatter();
                Fileformatter.Binder = new UBinder();
                return Fileformatter.Deserialize(stream) as ImgData;
            }

            public class UBinder : SerializationBinder
            {
                public override Type BindToType(string assemblyName, string typeName)
                {
                    if (typeName.EndsWith("ImgData"))
                    {
                        return typeof(ImgData);
                    }
                    return (Assembly.GetExecutingAssembly()).GetType(typeName);
                }
            }
        }

        [Serializable]
        internal class ImgData : IDisposable
        {
            public string id { get; set; }

            public string Date { get; set; }
            public string Hash { get; set; }

            public byte[] img { get; set; }
            public List<int> FromList { get; set; }
            public bool Status { get; set; }
            public string Type { get; set; }

            public byte[] Send()
            {
                using (MemoryStream stream = new MemoryStream())
                {
                    BinaryFormatter Formatter = new BinaryFormatter();
                    Formatter.Serialize(stream, this);
                    return stream.ToArray();
                }
            }

            public static ImgData ToClass(byte[] data)
            {
                using var stream = new MemoryStream(data);
                IFormatter Fileformatter = new BinaryFormatter();
                Fileformatter.Binder = new UBinder();
                return Fileformatter.Deserialize(stream) as ImgData;
            }

            public class UBinder : SerializationBinder
            {
                public override Type BindToType(string assemblyName, string typeName)
                {
                    if (typeName.EndsWith("ImgData"))
                    {
                        return typeof(ImgData);
                    }
                    return (Assembly.GetExecutingAssembly()).GetType(typeName);
                }
            }

            public void Dispose()
            {
                this.Dispose(true);
                GC.SuppressFinalize(this);
            }

            protected virtual void Dispose(bool disposing)
            {
                if (disposing)
                {
                    this.img = null;
                }
            }

            ~ImgData()
            {
                this.Dispose(false);
            }
        }

        public class SendData
        {
            public string id;
            public string from;
        }

        private void WriteToMessage(string s)
        {
            MessageList.Enqueue(s);
            if (MessageList.Count > 50)
                MessageList.TryDequeue(out string ss);
        }

        private string DataBase = "Image.db";

        public Image2Webp() : base(@"/Webp")
        {
            LiteDbMemoryHelper.Enable(true);
            using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}{DataBase};Connection=Direct;");
            if (!db.CollectionExists("ImgData"))
            {
                var SIS = db.GetCollection<ImgData>("ImgData");
                SIS.EnsureIndex(x => x.Date);
                SIS.EnsureIndex(x => x.Hash);
                SIS.EnsureIndex(x => x.id, true);
                SIS.EnsureIndex(x => x.Status);
                SIS.EnsureIndex(x => x.Type);
                var SIS2 = db.GetCollection("Data");
                SIS2.EnsureIndex("id", true);
            }
            if (File.Exists("SendMessageByte.dat"))
            {
                sendMessage = SendMessage.ToClass(File.ReadAllBytes("SendMessageByte.dat"));
            }

            #region 数据库读取

            _ = Task.Factory.StartNew(async () =>
         {
             sendMessage.ReadFromSIS = 0;
             do
             {
                 if (!Setting.SISDownloadIng && _sessionsCheck.Count != 0)
                 {
                     using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}SIS.db;ReadOnly=True;Connection=Direct;");
                     try
                     {
                         TryAddToList();
                         var SISDB = db.GetCollection<SISImgData>("ImgData");
                         //foreach (var id in SISDB.Find(Query.All(), skip: sendMessage.ReadFromSIS).Select(x => x.id))
                         var id = SISDB.Find(Query.All(), skip: sendMessage.ReadFromSIS).Where(x => x.img
                            != null).Select(x => x.id).First();
                         {
                             sendMessage.ReadFromSIS += 1;
                             if (!Read(id))
                             {
                                 var TempData = new SendData()
                                 {
                                     id = id,
                                     from = "SIS"
                                 };
                                 WriteSend.Add(TempData);
                                 //var item = SISDB.FindById(id);
                                 //if (item.img != null && item.img.Length > 1024)
                                 //{
                                 //    var TempData = new SendData()
                                 //    {
                                 //        Data = item.img,
                                 //        Date = item.Date,
                                 //        id = id,
                                 //        from = "SIS"
                                 //    };
                                 //    TempData.Send(memoryPool.Rent());
                                 //    ts.TryAdd(new Tuple<SISImgData, bool>(item, true));
                                 //    TryTime = 0;
                                 //    // var ms = new MemoryStream(item.img);
                                 //    // Image img = Image.FromStream(ms);
                                 //    // img.Dispose();
                                 //    //ms.Dispose();
                                 //}
                             }
                         }
                     }
                     catch (Exception ex)
                     {
                         var Message = $"SIS读取失败:{DateTime.Now:HH:m:s}-{ sendMessage.ReadFromSIS }-{ex}";
                         File.AppendAllLines("Error.txt", new string[] { Message });
                         WriteToMessage($"{Message}");
                     }
                     finally
                     {
                         db.Dispose();
                     }
                     GC.Collect();
                 }
                 else
                 {
                     await Task.Delay(1000);
                 }
             } while (true);
         });
            _ = Task.Factory.StartNew(async () =>
            {
                sendMessage.ReadFromT66y = 0;
                do
                {
                    if (!Setting.T66yDownloadIng && _sessionsCheck.Count != 0)
                    {
                        using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}T66y.db;ReadOnly=True;Connection=Direct;");
                        try
                        {
                            TryAddToList();
                            var T66yDB = db.GetCollection<T66yImgData>("ImgData");
                            //foreach (var id in T66yDB.Find(Query.All(), skip: sendMessage.ReadFromSIS).Select(x => x.id).First())
                            var id = T66yDB.Find(Query.All(), skip: sendMessage.ReadFromT66y).Where(x => x.img
                            != null).Select(x => x.id).First();
                            if (id != null)
                            {
                                sendMessage.ReadFromT66y += 1;
                                if (!Read(id))
                                {
                                    var TempData = new SendData()
                                    {
                                        id = id,
                                        from = "T66y"
                                    };
                                    WriteSend.Add(TempData);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            var Message = $"T66y读取失败:{DateTime.Now:HH:m:s}-{ sendMessage.ReadFromT66y }-{ex}";
                            File.AppendAllLines("Error.txt", new string[] { Message });
                            WriteToMessage($"{Message}");
                        }
                        finally
                        {
                            db.Dispose();
                        }
                        GC.Collect();
                    }
                    else
                    {
                        await Task.Delay(1000);
                    }
                } while (true);
            });
            bool Read(string Id)
            {
                var Flag = true;
                try
                {
                    {
                        using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}{DataBase};Connection=Direct;");
                        var ImageDB = db.GetCollection("Data");
                        Flag = ImageDB.Exists(x => x["id"] == Id);
                    }
                }
                catch (Exception ex)
                {
                    WriteToMessage($"{DateTime.Now:HH:m:s}Image读取错误{ex.Message}");
                }
                return Flag;
            }
            void TryAddToList()
            {
                if (DisConnectMission.Count != 0)
                {
                    var item = new SendData[DisConnectMission.Count];
                    DisConnectMission.TryPopRange(item);
                    foreach (var Temp in item)
                    {
                        WriteSend.Add(Temp);
                    }
                }
            }

            #endregion 数据库读取

            #region 发送数据

            _ = Task.Factory.StartNew(async () =>
            {
                do
                {
                    try
                    {
                        if (_sessions.Count != 0)
                        {
                            foreach (var session in _sessions)
                            {
                                var IpAddress = session.Value.RemoteEndPoint.Address.ToString();
                                if (_sessionsCheck[IpAddress])
                                {
                                    if (WriteSend.TryTake(out SendData SendItem))
                                    {
                                        switch (SendItem.from)
                                        {
                                            case "SIS":
                                                {
                                                    int SecondCount = 0;
                                                    while (Setting.SISDownloadIng)
                                                    {
                                                        await Task.Delay(1000);
                                                        SecondCount += 1;
                                                        WriteToMessage($"SIS发送等待:{SecondCount}秒");
                                                    }
                                                    using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}SIS.db;ReadOnly=True");
                                                    var SISDB = db.GetCollection<OriImgData>("ImgData");
                                                    var item = SISDB.FindById(SendItem.id);
                                                    if (item.img != null && item.img.Length > 1024)
                                                    {
                                                        sendMessage.SendCount += 1;
                                                        item.Status = true;
                                                        Interlocked.Increment(ref sendMessage.ClientCount[IpAddress].SendCount);
                                                        Interlocked.Add(ref sendMessage.ClientCount[IpAddress].SendByte, item.img.Length);
                                                        await session.Value.SendBinaryAsync(item.ToByte());
                                                        WriteToMessage($"正常发送数:{sendMessage.SendCount }");
                                                    }
                                                }
                                                break;

                                            case "T66y":
                                                {
                                                    int SecondCount = 0;
                                                    while (Setting.T66yDownloadIng)
                                                    {
                                                        await Task.Delay(1000);
                                                        SecondCount += 1;
                                                        WriteToMessage($"T66y发送等待:{SecondCount}秒");
                                                    }
                                                    using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}T66y.db;ReadOnly=True");
                                                    var T66yDB = db.GetCollection<OriImgData>("ImgData");
                                                    var item = T66yDB.FindById(SendItem.id);
                                                    if (item.img != null && item.img.Length > 1024)
                                                    {
                                                        sendMessage.SendCount += 1;
                                                        item.Status = false;
                                                        Interlocked.Increment(ref sendMessage.ClientCount[IpAddress].SendCount);
                                                        Interlocked.Add(ref sendMessage.ClientCount[IpAddress].SendByte, item.img.Length);
                                                        sendMessage.ClientCount[IpAddress].SendCount += 1;
                                                        sendMessage.ClientCount[IpAddress].SendByte += item.img.Length;
                                                        await session.Value.SendBinaryAsync(item.ToByte());
                                                        WriteToMessage($"正常发送数:{sendMessage.SendCount }");
                                                    }
                                                }
                                                break;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            await Task.Delay(1000);
                            WriteToMessage($"等待发送，总计数:{sendMessage.SendCount }");
                        }
                    }
                    catch (Exception ex)
                    {
                        WriteToMessage($"发送错误{ex.Message}");
                    }
                } while (true);
            });

            #endregion 发送数据

            #region 发送服务器信息

            _ = Task.Factory.StartNew(async () =>
            {
                do
                {
                    try
                    {
                        await Task.Delay(1000);

                        if (_sessions.Count != 0)
                        {
                            var SendData = sendMessage.Send();
                            var SendBase = Convert.ToBase64String(SendData);
                            await File.WriteAllBytesAsync("SendMessageByte.dat", SendData);
                            SendData = null;
                            foreach (var session in _sessions)
                            {
                                await session.Value.SendTextAsync(SendBase);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                } while (true);
            });

            #endregion 发送服务器信息

            #region 保存到数据库

            _ = Task.Factory.StartNew(() =>
            {
                foreach (var item in WriteSave.GetConsumingEnumerable())
                {
                    using var db = new LiteDatabase($@"Filename={DataBaseCommand.BaseUri}{DataBase};Connection=Shared");
                    var SISDB = db.GetCollection<ImgData>("ImgData");
                    var SISDB2 = db.GetCollection("Data");
                    int SAVECount = 0;
                back:
                    try
                    {
                        if (item.img != null)
                        {
                            SISDB2.Upsert(new BsonDocument() { { "id", item.id } });
                            SISDB.Upsert(item);
                            sendMessage.SaveCount += 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        SAVECount += 1;
                        File.WriteAllLines("Error.txt", new string[] { $"保存失败{ex}|{item.id}" });
                        WriteToMessage($"{DateTime.Now:HH:m:s}保存失败{ex}");
                        if (SAVECount == 5)
                            continue;
                        else
                            goto back;
                    }
                }
            });

            #endregion 保存到数据库
        }

        public override async Task OnSessionStarted(AsyncWebSocketSession session)
        {
            var IpAddress = session.RemoteEndPoint.Address.ToString();
            _sessions.TryAdd(session.SessionKey, session);
            _sessionsCheck.TryAdd(IpAddress, true);
            _sessionsMission.TryAdd(IpAddress, new List<SendData>());
            if (!sendMessage.ClientCount.ContainsKey(IpAddress))
            {
                sendMessage.ClientCount.Add(IpAddress, new CLientInfo());
            }
            Loger.Instance.ServerInfo("主机", $"Webp设备远程{session.RemoteEndPoint}连接");
            await Task.CompletedTask;
        }

        public override async Task OnSessionClosed(AsyncWebSocketSession session)
        {
            var IpAddress = session.RemoteEndPoint.Address.ToString();
            Loger.Instance.ServerInfo("主机", $"Webp设备远程{session.RemoteEndPoint}断开");
            _sessions.TryRemove(session.SessionKey, out AsyncWebSocketSession throwAway);
            _sessionsCheck.TryRemove(IpAddress, out bool check);
            _sessionsMission.TryRemove(IpAddress, out List<SendData> value);
            sendMessage.ClientCount.Remove(IpAddress);
            DisConnectMission.PushRange(value.ToArray());
            await Task.CompletedTask;
        }

        public override async Task OnSessionTextReceived(AsyncWebSocketSession session, string text)
        {
            var IpAddress = session.RemoteEndPoint.Address.ToString();
            _sessionsCheck[IpAddress] = text == "true";
            WriteToMessage($"设置{session.RemoteEndPoint}为{_sessionsCheck[IpAddress]}");
            await Task.CompletedTask;
        }

        public override async Task OnSessionBinaryReceived(AsyncWebSocketSession session, byte[] data, int offset, int count)
        {
            var GetData = ImgData.ToClass(data);
            if (GetData.img != null && GetData.img.Length > 1000)
            {
                var IpAddress = session.RemoteEndPoint.Address.ToString();
                Interlocked.Increment(ref sendMessage.ClientCount[IpAddress].GetCount);
                Interlocked.Add(ref sendMessage.ClientCount[IpAddress].GetByte, GetData.img.Length);
                WriteSave.Add(GetData);
                if (_sessionsMission.ContainsKey(IpAddress))
                {
                    var Find = _sessionsMission[IpAddress].FindIndex(x => x.id == GetData.id);
                    if (Find != -1)
                    {
                        _sessionsMission[IpAddress].RemoveAt(Find);
                    }
                }
            }
            await Task.CompletedTask;
        }
    }

    internal static class LiteDbMemoryHelper
    {
        private const int CACHE_SIZE_THRESHOLD = 1024;
        private const int PERIODIC_CLEANUP_SECONDS = 60; // 1 Minutes

        private static FieldInfo _ScalarCacheFieldInfo;
        private static FieldInfo _EnumerableCacheFieldInfo;
        private static Timer _CleanupTimer;

        public static void Enable(bool enable)
        {
            if (enable)
            {
                _ScalarCacheFieldInfo ??= GetScalarExpressionCacheFieldInfo();
                _EnumerableCacheFieldInfo ??= GetEnumerableExpressionCacheFieldInfo();

                if (_ScalarCacheFieldInfo == null || _EnumerableCacheFieldInfo == null)
                {
                }
                else
                {
                    var ts = TimeSpan.FromSeconds(PERIODIC_CLEANUP_SECONDS);
                    _CleanupTimer ??= new Timer(OnCleanupCallback, null, ts, ts);
                }
            }
            else if (_CleanupTimer != null)
            {
                _CleanupTimer.Change(Timeout.InfiniteTimeSpan, Timeout.InfiniteTimeSpan);
                _CleanupTimer.Dispose();
                _CleanupTimer = null;
            }
        }

        private static FieldInfo GetScalarExpressionCacheFieldInfo()
        {
            var type = typeof(BsonExpression);
            return type.GetField("_cacheScalar", BindingFlags.NonPublic | BindingFlags.Static);
        }

        private static FieldInfo GetEnumerableExpressionCacheFieldInfo()
        {
            var type = typeof(BsonExpression);
            return type.GetField("_cacheEnumerable", BindingFlags.NonPublic | BindingFlags.Static);
        }

        private static void OnCleanupCallback(object _)
        {
            try
            {
                // The actual dictionary value type is not public available.
                // For clearing we do not need it. We can just use the general purpose IDictionary interface.
                var scalarExpressionCache = _ScalarCacheFieldInfo.GetValue(null);
                if (scalarExpressionCache is IDictionary scalarCacheDictionary)
                {
                    CleanupDictionaryIfNecessary(scalarCacheDictionary);
                }
                else
                {
                }

                var enumerableExpressionCache = _EnumerableCacheFieldInfo.GetValue(null);
                if (enumerableExpressionCache is IDictionary enumerableCacheDictionary)
                {
                    CleanupDictionaryIfNecessary(enumerableCacheDictionary);
                }
                else
                {
                }
            }
            catch (Exception e)
            {
            }
        }

        private static void CleanupDictionaryIfNecessary(IDictionary dictionary)
        {
            var currentSize = dictionary.Count;
            if (currentSize > CACHE_SIZE_THRESHOLD)
            {
                dictionary.Clear();
            }
        }
    }
}